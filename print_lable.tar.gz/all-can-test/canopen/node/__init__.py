from .remote import RemoteNode
from .local import LocalNode
